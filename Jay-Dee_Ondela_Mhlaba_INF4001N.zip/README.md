# Geopolitics Game - UCT INF4001N Entrance Exam

## Live URL
https://geopolitics-game.onrender.com

## Tech Stack
- Node.js, Express
- MongoDB Atlas (NoSQL)
- Google Gemini AI (for battle commentary)
- JWT Authentication

## How to Run Locally
1. Clone the repository.
2. Run `npm install`.
3. Create a `.env` file with MONGODB_URI, JWT_SECRET, and GEMINI_API_KEY.
4. Run `node server.js`.

## Test Credentials
- Username: jaydee
- Password: test1234

## Database Access
- (Put your MongoDB username and password here so the graders can view the database)